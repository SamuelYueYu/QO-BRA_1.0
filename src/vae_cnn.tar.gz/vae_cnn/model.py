"""
VAE CNN - Model Module

This module defines a 1D-CNN based Variational Autoencoder (VAE) for
continuous sequence tokens. CNNs are better suited for sequence data
as they can capture local patterns and motifs efficiently.

Architecture:
- Encoder: 1D Conv layers that progressively downsample the sequence
- Latent: Gaussian with reparameterization trick
- Decoder: 1D ConvTranspose layers that upsample back to sequence length
- Loss: Gaussian reconstruction (MSE) + KL divergence
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvVAE(nn.Module):
    """
    1D-CNN based Variational Autoencoder for continuous sequence tokens.
    
    The model uses:
    - Encoder: Conv1d -> BatchNorm -> ReLU -> ... -> Flatten -> (mu, logvar)
    - Decoder: Linear -> Reshape -> ConvTranspose1d -> BatchNorm -> ReLU -> ...
    - Gaussian likelihood with fixed or learned sigma
    """
    
    def __init__(self, seq_len: int = 128, latent_dim: int = 32,
                 channels: list = None, kernel_size: int = 5,
                 dropout: float = 0.1):
        """
        Initialize the CNN VAE.
        
        Parameters:
        - seq_len: Length of input sequences (L)
        - latent_dim: Dimension of latent space
        - channels: List of channel sizes for conv layers (default: [32, 64, 128])
        - kernel_size: Kernel size for conv layers (odd number recommended)
        - dropout: Dropout rate (0 to disable)
        """
        super().__init__()
        
        if channels is None:
            channels = [32, 64, 128]
        
        self.seq_len = seq_len
        self.latent_dim = latent_dim
        self.channels = channels
        self.kernel_size = kernel_size
        
        # Padding to maintain sequence length with stride=1
        padding = kernel_size // 2
        
        # =====================================================================
        # ENCODER: Conv1d layers with stride=2 for downsampling
        # Input shape: (batch, 1, seq_len) -> Output: (batch, channels[-1], reduced_len)
        # =====================================================================
        encoder_layers = []
        in_channels = 1
        
        for out_channels in channels:
            encoder_layers.extend([
                nn.Conv1d(in_channels, out_channels, kernel_size, stride=2, padding=padding),
                nn.BatchNorm1d(out_channels),
                nn.ReLU(inplace=True),
            ])
            if dropout > 0:
                encoder_layers.append(nn.Dropout(dropout))
            in_channels = out_channels
        
        self.encoder = nn.Sequential(*encoder_layers)
        
        # Calculate the flattened size after conv layers
        # Each conv with stride=2 roughly halves the sequence length
        self.encoded_len = seq_len
        for _ in channels:
            self.encoded_len = (self.encoded_len + 2 * padding - kernel_size) // 2 + 1
        
        self.flat_size = channels[-1] * self.encoded_len
        
        # Latent space projections
        self.fc_mu = nn.Linear(self.flat_size, latent_dim)
        self.fc_logvar = nn.Linear(self.flat_size, latent_dim)
        
        # =====================================================================
        # DECODER: ConvTranspose1d layers with stride=2 for upsampling
        # Input shape: (batch, latent_dim) -> Output: (batch, 1, seq_len)
        # =====================================================================
        self.fc_decode = nn.Linear(latent_dim, self.flat_size)
        
        decoder_layers = []
        reversed_channels = list(reversed(channels))
        
        for i, out_channels in enumerate(reversed_channels[1:] + [1]):
            in_ch = reversed_channels[i]
            is_last = (out_channels == 1)
            
            decoder_layers.append(
                nn.ConvTranspose1d(in_ch, out_channels, kernel_size, stride=2, 
                                   padding=padding, output_padding=1)
            )
            
            if not is_last:
                decoder_layers.extend([
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU(inplace=True),
                ])
                if dropout > 0:
                    decoder_layers.append(nn.Dropout(dropout))
        
        self.decoder = nn.Sequential(*decoder_layers)
        
        # Initialize weights
        self._init_weights()
    
    def _init_weights(self):
        """Initialize weights with Xavier/Kaiming initialization."""
        for m in self.modules():
            if isinstance(m, (nn.Conv1d, nn.ConvTranspose1d)):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
    
    def encode(self, x: torch.Tensor):
        """
        Encode input sequences to latent distribution parameters.
        
        Parameters:
        - x: Input tensor of shape (batch, seq_len)
        
        Returns:
        - mu: Mean of latent distribution (batch, latent_dim)
        - logvar: Log variance of latent distribution (batch, latent_dim)
        """
        # Add channel dimension: (batch, seq_len) -> (batch, 1, seq_len)
        x = x.unsqueeze(1)
        
        # Encode
        h = self.encoder(x)
        h = h.view(h.size(0), -1)  # Flatten
        
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar
    
    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor):
        """
        Reparameterization trick: sample z = mu + sigma * epsilon.
        
        Parameters:
        - mu: Mean of latent distribution
        - logvar: Log variance of latent distribution
        
        Returns:
        - z: Sampled latent vector
        """
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def decode(self, z: torch.Tensor):
        """
        Decode latent vectors to reconstructed sequences.
        
        Parameters:
        - z: Latent tensor of shape (batch, latent_dim)
        
        Returns:
        - x_recon: Reconstructed sequences (batch, seq_len)
        """
        h = self.fc_decode(z)
        h = h.view(h.size(0), self.channels[-1], self.encoded_len)
        
        x_recon = self.decoder(h)
        
        # Remove channel dimension and adjust length
        x_recon = x_recon.squeeze(1)
        
        # Ensure output matches input sequence length
        if x_recon.size(1) != self.seq_len:
            x_recon = F.interpolate(x_recon.unsqueeze(1), size=self.seq_len, 
                                    mode='linear', align_corners=False).squeeze(1)
        
        # Clamp outputs to [0, 1] range to ensure valid token values
        x_recon = torch.clamp(x_recon, 0.0, 1.0)
        
        return x_recon
    
    def forward(self, x: torch.Tensor, deterministic: bool = False):
        """
        Forward pass through the VAE.
        
        Parameters:
        - x: Input tensor of shape (batch, seq_len)
        - deterministic: If True, use mu directly instead of sampling (no stochastic noise)
        
        Returns:
        - x_recon: Reconstructed sequences
        - mu: Latent mean
        - logvar: Latent log variance
        """
        mu, logvar = self.encode(x)
        if deterministic:
            z = mu  # Use mean directly, no sampling noise
        else:
            z = self.reparameterize(mu, logvar)
        x_recon = self.decode(z)
        return x_recon, mu, logvar
    
    def sample(self, n_samples: int, device: torch.device):
        """
        Sample new sequences from the prior.
        
        Parameters:
        - n_samples: Number of samples to generate
        - device: Device to generate samples on
        
        Returns:
        - samples: Generated sequences (n_samples, seq_len)
        """
        z = torch.randn(n_samples, self.latent_dim, device=device)
        samples = self.decode(z)
        return samples


def vae_loss(x: torch.Tensor, x_recon: torch.Tensor, 
             mu: torch.Tensor, logvar: torch.Tensor,
             beta: float = 1.0):
    """
    Compute VAE loss: reconstruction loss + beta * KL divergence.
    
    Parameters:
    - x: Original input (batch, seq_len)
    - x_recon: Reconstructed output (batch, seq_len)
    - mu: Latent mean (batch, latent_dim)
    - logvar: Latent log variance (batch, latent_dim)
    - beta: Weight for KL term (beta-VAE)
    
    Returns:
    - loss: Total loss
    - recon_loss: Reconstruction loss component
    - kl_loss: KL divergence component
    """
    batch_size = x.size(0)
    
    # Reconstruction loss (MSE, summed over sequence, averaged over batch)
    recon_loss = F.mse_loss(x_recon, x, reduction='sum') / batch_size
    
    # Clamp logvar to prevent NaN from exp overflow
    logvar_clamped = logvar.clamp(min=-20.0, max=20.0)
    
    # KL divergence (summed over latent dims, averaged over batch)
    kl_loss = -0.5 * torch.sum(1 + logvar_clamped - mu.pow(2) - logvar_clamped.exp()) / batch_size
    
    # Total loss (negative ELBO)
    loss = recon_loss + beta * kl_loss
    
    return loss, recon_loss, kl_loss

