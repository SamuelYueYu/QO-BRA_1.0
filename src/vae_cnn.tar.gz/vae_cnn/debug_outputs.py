#!/usr/bin/env python
"""Debug script to check model output distributions."""

import torch
import numpy as np
import torch.nn.functional as F
from model import ConvVAE
from data import load_data, get_dataloaders

# Load model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = ConvVAE(seq_len=128, latent_dim=32, channels=[32, 64, 128], kernel_size=5, dropout=0.1).to(device)

# Load checkpoint
checkpoint = torch.load('./outputs/Ca/best_model.pt', map_location=device)
model.load_state_dict(checkpoint['model_state_dict'])
model.eval()

# Load some data
train_dataset, val_dataset, token_to_value, value_to_token = load_data(
    '../src/Training data', 'Ca', 128, 0.2, 42)
train_loader, val_loader = get_dataloaders(train_dataset, val_dataset, 64)


def decode_no_clamp(z):
    """Decode without clamping to see raw values."""
    h = model.fc_decode(z)
    h = h.view(h.size(0), model.channels[-1], model.encoded_len)
    x_recon = model.decoder(h)
    x_recon = x_recon.squeeze(1)
    if x_recon.size(1) != model.seq_len:
        x_recon = F.interpolate(x_recon.unsqueeze(1), size=model.seq_len, 
                                mode='linear', align_corners=False).squeeze(1)
    return x_recon  # No clamping!


# Get a batch and check outputs
with torch.no_grad():
    batch = next(iter(val_loader)).to(device)
    
    # Encode
    mu, logvar = model.encode(batch)
    z = mu  # deterministic
    
    # Decode without clamping
    x_recon_raw = decode_no_clamp(z)
    
    # Before clamping - check raw output range
    print('=' * 60)
    print('RAW MODEL OUTPUT (before clamping):')
    print('=' * 60)
    print('Shape:', x_recon_raw.shape)
    print('Min:', round(x_recon_raw.min().item(), 4))
    print('Max:', round(x_recon_raw.max().item(), 4))
    print('Mean:', round(x_recon_raw.mean().item(), 4))
    print('Std:', round(x_recon_raw.std().item(), 4))
    
    # Check distribution in bins
    flat = x_recon_raw.cpu().numpy().flatten()
    n = len(flat)
    print('\nDistribution of raw outputs:')
    print('  < 0.0:', round((flat < 0).sum() / n * 100, 1), '%')
    print('  0.0-0.2:', round(((flat >= 0) & (flat < 0.2)).sum() / n * 100, 1), '%')
    print('  0.2-0.4:', round(((flat >= 0.2) & (flat < 0.4)).sum() / n * 100, 1), '%')
    print('  0.4-0.6:', round(((flat >= 0.4) & (flat < 0.6)).sum() / n * 100, 1), '%')
    print('  0.6-0.8:', round(((flat >= 0.6) & (flat < 0.8)).sum() / n * 100, 1), '%')
    print('  0.8-1.0:', round(((flat >= 0.8) & (flat < 1.0)).sum() / n * 100, 1), '%')
    print('  > 1.0:', round((flat > 1.0).sum() / n * 100, 1), '%')
    
    # Check input distribution for comparison
    input_flat = batch.cpu().numpy().flatten()
    valid_input = input_flat[input_flat >= 0]  # Exclude padding
    print('')
    print('=' * 60)
    print('INPUT DATA (for comparison):')
    print('=' * 60)
    print('Total positions:', len(input_flat))
    print('Padding positions:', (input_flat < 0).sum())
    print('Valid positions:', len(valid_input))
    print('Min (excl padding):', round(valid_input.min(), 4))
    print('Max:', round(valid_input.max(), 4))
    print('Mean:', round(valid_input.mean(), 4))
    print('Std:', round(valid_input.std(), 4))
    nv = len(valid_input)
    print('\nDistribution of inputs (excl padding):')
    print('  0.0-0.2:', round(((valid_input >= 0) & (valid_input < 0.2)).sum() / nv * 100, 1), '%')
    print('  0.2-0.4:', round(((valid_input >= 0.2) & (valid_input < 0.4)).sum() / nv * 100, 1), '%')
    print('  0.4-0.6:', round(((valid_input >= 0.4) & (valid_input < 0.6)).sum() / nv * 100, 1), '%')
    print('  0.6-0.8:', round(((valid_input >= 0.6) & (valid_input < 0.8)).sum() / nv * 100, 1), '%')
    print('  0.8-1.0:', round(((valid_input >= 0.8) & (valid_input <= 1.0)).sum() / nv * 100, 1), '%')
    
    # Check latent space
    print('')
    print('=' * 60)
    print('LATENT SPACE:')
    print('=' * 60)
    print('mu - Min:', round(mu.min().item(), 4), ', Max:', round(mu.max().item(), 4))
    print('mu - Mean:', round(mu.mean().item(), 4), ', Std:', round(mu.std().item(), 4))
    print('logvar - Min:', round(logvar.min().item(), 4), ', Max:', round(logvar.max().item(), 4))
    print('logvar - Mean:', round(logvar.mean().item(), 4))
    print('sigma (exp(0.5*logvar)) - Mean:', round(torch.exp(0.5*logvar).mean().item(), 4))
    
    # Check sampled outputs (from prior)
    z_prior = torch.randn(64, 32, device=device)
    samples_raw = decode_no_clamp(z_prior)
    
    print('')
    print('=' * 60)
    print('SAMPLES FROM PRIOR (z ~ N(0,1)):')
    print('=' * 60)
    print('Min:', round(samples_raw.min().item(), 4))
    print('Max:', round(samples_raw.max().item(), 4))
    print('Mean:', round(samples_raw.mean().item(), 4))
    print('Std:', round(samples_raw.std().item(), 4))
    
    flat_samples = samples_raw.cpu().numpy().flatten()
    ns = len(flat_samples)
    print('\nDistribution of sampled outputs:')
    print('  < 0.0:', round((flat_samples < 0).sum() / ns * 100, 1), '%')
    print('  0.0-0.2:', round(((flat_samples >= 0) & (flat_samples < 0.2)).sum() / ns * 100, 1), '%')
    print('  0.2-0.4:', round(((flat_samples >= 0.2) & (flat_samples < 0.4)).sum() / ns * 100, 1), '%')
    print('  0.4-0.6:', round(((flat_samples >= 0.4) & (flat_samples < 0.6)).sum() / ns * 100, 1), '%')
    print('  0.6-0.8:', round(((flat_samples >= 0.6) & (flat_samples < 0.8)).sum() / ns * 100, 1), '%')
    print('  0.8-1.0:', round(((flat_samples >= 0.8) & (flat_samples < 1.0)).sum() / ns * 100, 1), '%')
    print('  > 1.0:', round((flat_samples > 1.0).sum() / ns * 100, 1), '%')
    
    # Show token value mapping
    print('')
    print('=' * 60)
    print('TOKEN VALUE MAPPING (first 10 and last 5):')
    print('=' * 60)
    tokens = list(token_to_value.keys())
    for i, t in enumerate(tokens[:10]):
        print('  %d: "%s" -> %.4f' % (i, t, token_to_value[t]))
    print('  ...')
    for i, t in enumerate(tokens[-5:], len(tokens)-5):
        print('  %d: "%s" -> %.4f' % (i, t, token_to_value[t]))
