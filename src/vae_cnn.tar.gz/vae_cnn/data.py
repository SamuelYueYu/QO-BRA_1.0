"""
VAE CNN - Data Module

This module handles data loading and preprocessing for the sequence VAE.
It reads protein sequences from the training data folders and converts them
to continuous real-valued token vectors using a frequency-based encoding scheme.
"""

import os
import random
from collections import Counter
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader


# Standard 20 amino acid codes
AMINO_ACIDS = ['A', 'C', 'D', 'E', 'F', 
               'G', 'H', 'I', 'K', 'L', 
               'M', 'N', 'P', 'Q', 'R', 
               'S', 'T', 'V', 'W', 'Y']

# Special characters in sequence encoding
BINDING_MARKER = '+'  # Marks metal-binding residues
CHAIN_SEPARATOR = ':'  # Separates protein chains
TERMINATOR = 'X'  # Sequence terminator


def build_token_list():
    """
    Build comprehensive token list for sequence encoding.
    
    Returns:
    - tokens: List of all possible tokens (AA, AA+, :, :X)
    """
    tokens = []
    # Regular amino acids
    for aa in AMINO_ACIDS:
        tokens.append(aa)
    # Metal-binding amino acids (marked with '+')
    for aa in AMINO_ACIDS:
        tokens.append(aa + BINDING_MARKER)
    # Special tokens
    tokens.append(CHAIN_SEPARATOR)
    tokens.append(CHAIN_SEPARATOR + TERMINATOR)
    return tokens


def build_token_mappings():
    """
    Build simple token-to-value mappings using normalized indices.
    
    Each token is assigned a value in [0, 1] based on its index:
    value = index / (vocab_size - 1)
    
    This gives evenly spaced, deterministic token values.
    
    Returns:
    - token_to_value: Dict mapping token strings to float values in [0, 1]
    - value_to_token: Dict mapping float values to token strings
    - vocab_size: Number of unique tokens
    """
    tokens = build_token_list()
    vocab_size = len(tokens)
    
    token_to_value = {}
    value_to_token = {}
    
    for idx, token in enumerate(tokens):
        # Map to [0, 1] range with even spacing
        value = idx / (vocab_size - 1) if vocab_size > 1 else 0.5
        token_to_value[token] = value
        value_to_token[value] = token
    
    return token_to_value, value_to_token, vocab_size


def read_sequences_from_folder(folder_path: str):
    """
    Read all protein sequences from a folder.
    
    Parameters:
    - folder_path: Path to folder containing .txt sequence files
    
    Returns:
    - sequences: List of protein sequence strings
    - filenames: List of corresponding filenames (PDB codes)
    """
    sequences = []
    filenames = []
    
    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"Data folder not found: {folder_path}")
    
    for filename in sorted(os.listdir(folder_path)):
        if filename.endswith('.txt') and not filename.startswith('.'):
            filepath = os.path.join(folder_path, filename)
            with open(filepath, 'r') as f:
                lines = f.readlines()
            
            # Use the first line (with binding site markers) if available
            if lines:
                seq = lines[0].strip()
                if seq:
                    sequences.append(seq)
                    filenames.append(filename[:-4])  # Remove .txt
    
    return sequences, filenames


def sequence_to_tokens(sequence: str, token_to_value: dict, max_len: int):
    """
    Convert a protein sequence to a vector of continuous token values.
    
    Parameters:
    - sequence: Protein sequence string
    - token_to_value: Dictionary mapping tokens to values in [0, 1]
    - max_len: Maximum sequence length (for padding/truncation)
    
    Returns:
    - token_vector: numpy array of shape (max_len,) with values in [0, 1]
    """
    tokens = []
    i = 0
    
    while i < len(sequence) and len(tokens) < max_len:
        if i < len(sequence) - 1 and sequence[i + 1] in [BINDING_MARKER, TERMINATOR]:
            token = sequence[i:i + 2]
            i += 2
        else:
            token = sequence[i]
            i += 1
        
        if token in token_to_value:
            tokens.append(token_to_value[token])
        else:
            # Unknown token: use -1 as a sentinel (outside [0,1] range)
            tokens.append(-1.0)
    
    # Pad with -1 (distinguishable from valid tokens which are in [0,1])
    while len(tokens) < max_len:
        tokens.append(-1.0)
    
    return np.array(tokens[:max_len], dtype=np.float32)


def tokens_to_sequence(token_vector: np.ndarray, value_to_token: dict, 
                       token_to_value: dict) -> str:
    """
    Convert a continuous token vector back to a protein sequence.
    
    Parameters:
    - token_vector: numpy array of token values
    - value_to_token: Dictionary mapping values to tokens (not used, kept for API compat)
    - token_to_value: Dictionary mapping tokens to values (used for nearest lookup)
    
    Returns:
    - sequence: Decoded protein sequence string
    """
    # Get all valid tokens and their values
    token_strings = list(token_to_value.keys())
    token_values = np.array(list(token_to_value.values()))
    
    sequence = ""
    for val in token_vector:
        # Skip padding tokens
        if val < 0:
            continue
        
        # Find nearest token by value
        idx = np.argmin(np.abs(token_values - val))
        sequence += token_strings[idx]
    
    return sequence


class SequenceDataset(Dataset):
    """
    PyTorch Dataset for protein sequences encoded as continuous token vectors.
    """
    
    def __init__(self, sequences: list, token_to_value: dict, max_len: int):
        """
        Initialize dataset.
        
        Parameters:
        - sequences: List of protein sequence strings
        - token_to_value: Dictionary mapping tokens to values in [0, 1]
        - max_len: Maximum sequence length
        """
        self.sequences = sequences
        self.token_to_value = token_to_value
        self.max_len = max_len
        
        # Pre-compute token vectors
        self.token_vectors = []
        for seq in sequences:
            vec = sequence_to_tokens(seq, token_to_value, max_len)
            self.token_vectors.append(vec)
        
        self.token_vectors = np.stack(self.token_vectors, axis=0)
    
    def __len__(self):
        return len(self.sequences)
    
    def __getitem__(self, idx):
        return torch.from_numpy(self.token_vectors[idx])


def load_data(data_dir: str, metal: str, max_len: int = 128, 
              val_split: float = 0.2, seed: int = 42):
    """
    Load and prepare data for training.
    
    Parameters:
    - data_dir: Path to Training data directory
    - metal: Metal type subfolder (Ca, Mg, or Zn)
    - max_len: Maximum sequence length
    - val_split: Fraction of data to use for validation
    - seed: Random seed for reproducibility
    
    Returns:
    - train_dataset: Training dataset
    - val_dataset: Validation dataset
    - token_to_value: Token to value mapping (values in [0, 1])
    - value_to_token: Value to token mapping
    """
    folder_path = os.path.join(data_dir, f"{metal}_bind")
    sequences, filenames = read_sequences_from_folder(folder_path)
    
    if len(sequences) == 0:
        raise ValueError(f"No sequences found in {folder_path}")
    
    print(f"Loaded {len(sequences)} sequences from {folder_path}")
    
    # Build simple token mappings (index-based, not frequency-based)
    token_to_value, value_to_token, vocab_size = build_token_mappings()
    print(f"Vocabulary size: {vocab_size} tokens, values in [0, 1]")
    
    # Split into train/val
    random.seed(seed)
    indices = list(range(len(sequences)))
    random.shuffle(indices)
    
    split_idx = int(len(indices) * (1 - val_split))
    train_indices = indices[:split_idx]
    val_indices = indices[split_idx:]
    
    train_seqs = [sequences[i] for i in train_indices]
    val_seqs = [sequences[i] for i in val_indices]
    
    print(f"Train: {len(train_seqs)}, Val: {len(val_seqs)}")
    
    train_dataset = SequenceDataset(train_seqs, token_to_value, max_len)
    val_dataset = SequenceDataset(val_seqs, token_to_value, max_len)
    
    return train_dataset, val_dataset, token_to_value, value_to_token


def get_dataloaders(train_dataset: Dataset, val_dataset: Dataset,
                    batch_size: int = 256, num_workers: int = 0):
    """
    Create DataLoaders for training and validation.
    
    Parameters:
    - train_dataset: Training dataset
    - val_dataset: Validation dataset
    - batch_size: Batch size (use len(dataset) for full-batch)
    - num_workers: Number of data loading workers
    
    Returns:
    - train_loader: Training DataLoader
    - val_loader: Validation DataLoader
    """
    # Handle full-batch case
    train_bs = min(batch_size, len(train_dataset))
    val_bs = min(batch_size, len(val_dataset))
    
    train_loader = DataLoader(
        train_dataset, 
        batch_size=train_bs, 
        shuffle=True,
        num_workers=num_workers,
        drop_last=False
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=val_bs,
        shuffle=False,
        num_workers=num_workers,
        drop_last=False
    )
    
    return train_loader, val_loader

