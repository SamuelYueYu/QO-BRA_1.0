"""
VAE CNN - Utilities Module

This module provides utility functions for training and evaluation.
"""

import os
import random
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import (Rectangle, FancyBboxPatch, FancyArrowPatch, 
                                 Circle, ConnectionPatch)


def set_seed(seed: int):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def save_checkpoint(model, optimizer, epoch, loss, path):
    """
    Save model checkpoint.
    
    Parameters:
    - model: PyTorch model
    - optimizer: Optimizer
    - epoch: Current epoch
    - loss: Current loss value
    - path: Path to save checkpoint
    """
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss,
    }, path)


def load_checkpoint(model, optimizer, path, device):
    """
    Load model checkpoint.
    
    Parameters:
    - model: PyTorch model
    - optimizer: Optimizer
    - path: Path to checkpoint
    - device: Device to load to
    
    Returns:
    - epoch: Epoch from checkpoint
    - loss: Loss from checkpoint
    """
    checkpoint = torch.load(path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    if optimizer is not None:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['epoch'], checkpoint['loss']


class EarlyStopping:
    """
    Early stopping handler to stop training when validation loss stops improving.
    """
    
    def __init__(self, patience: int = 10, min_delta: float = 0.0):
        """
        Initialize early stopping.
        
        Parameters:
        - patience: Number of epochs to wait for improvement
        - min_delta: Minimum change to qualify as an improvement
        """
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float('inf')
    
    def __call__(self, val_loss: float) -> bool:
        """
        Check if training should stop.
        
        Parameters:
        - val_loss: Current validation loss
        
        Returns:
        - stop: True if training should stop
        """
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
            return False
        else:
            self.counter += 1
            return self.counter >= self.patience


def count_parameters(model):
    """Count the number of trainable parameters in a model."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_model_summary(model, seq_len):
    """
    Generate a text summary of the model architecture.
    
    Parameters:
    - model: PyTorch model
    - seq_len: Input sequence length
    
    Returns:
    - summary: String containing architecture summary
    """
    lines = []
    lines.append("=" * 60)
    lines.append("MODEL ARCHITECTURE SUMMARY (CNN VAE)")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Input: [{seq_len}] (continuous token values)")
    lines.append("")
    lines.append("--- ENCODER ---")
    lines.append(f"  Channels: 1 -> {' -> '.join(map(str, model.channels))}")
    lines.append(f"  Kernel size: {model.kernel_size}")
    lines.append(f"  Encoded length: {model.encoded_len}")
    lines.append(f"  Flat size: {model.flat_size}")
    lines.append(f"  |-- Linear (mu): {model.flat_size} -> {model.latent_dim}")
    lines.append(f"  +-- Linear (logvar): {model.flat_size} -> {model.latent_dim}")
    lines.append("")
    lines.append("--- LATENT ---")
    lines.append(f"  Reparameterization: z = mu + sigma * epsilon, dim={model.latent_dim}")
    lines.append("")
    lines.append("--- DECODER ---")
    lines.append(f"  Linear: {model.latent_dim} -> {model.flat_size}")
    lines.append(f"  Channels: {' -> '.join(map(str, reversed(model.channels)))} -> 1")
    lines.append(f"  Output: [{seq_len}]")
    lines.append("")
    lines.append("--- PARAMETERS ---")
    
    total_params = count_parameters(model)
    lines.append(f"  Total: {total_params:,}")
    lines.append(f"  Trainable: {total_params:,}")
    lines.append("")
    lines.append("=" * 60)
    
    return "\n".join(lines)


def save_model_summary(model, save_path, seq_len):
    """Save model architecture summary to a file."""
    summary = get_model_summary(model, seq_len)
    with open(save_path, 'w') as f:
        f.write(summary)
    print(f"Model summary saved to: {save_path}")


def plot_model_architecture(model, seq_len, save_path):
    """
    Plot a schematic diagram of the CNN VAE architecture.
    
    Parameters:
    - model: ConvVAE model instance
    - seq_len: Input sequence length
    - save_path: Path to save the plot
    """
    fig, ax = plt.subplots(1, 1, figsize=(16, 10))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Colors
    encoder_color = '#4A90E2'  # Blue
    latent_color = '#7B68EE'   # Purple
    decoder_color = '#50C878'  # Green
    text_color = '#333333'
    
    # Calculate positions
    encoder_x = 1.0
    latent_x = 5.0
    decoder_x = 7.5
    center_y = 5.0
    
    # Title
    ax.text(5, 9.5, 'CNN VAE Architecture', fontsize=20, fontweight='bold',
            ha='center', color=text_color)
    
    # =====================================================================
    # ENCODER SECTION
    # =====================================================================
    encoder_box = FancyBboxPatch((encoder_x - 0.4, center_y - 3.5), 0.8, 7.0,
                                boxstyle="round,pad=0.1", 
                                facecolor=encoder_color, alpha=0.2,
                                edgecolor=encoder_color, linewidth=2)
    ax.add_patch(encoder_box)
    ax.text(encoder_x, center_y + 3.2, 'ENCODER', fontsize=14, fontweight='bold',
            ha='center', color=encoder_color)
    
    # Input
    input_box = Rectangle((encoder_x - 0.3, center_y + 2.5), 0.6, 0.4,
                         facecolor='white', edgecolor=encoder_color, linewidth=1.5)
    ax.add_patch(input_box)
    ax.text(encoder_x, center_y + 2.7, f'Input\n[{seq_len}]', fontsize=9,
            ha='center', va='center', color=text_color)
    
    # Encoder layers
    y_pos = center_y + 1.8
    in_channels = 1
    current_len = seq_len
    
    for i, out_channels in enumerate(model.channels):
        # Conv1d block
        conv_box = Rectangle((encoder_x - 0.35, y_pos - 0.3), 0.7, 0.6,
                            facecolor='white', edgecolor=encoder_color, linewidth=1.5)
        ax.add_patch(conv_box)
        ax.text(encoder_x, y_pos, f'Conv1d\n{in_channels}→{out_channels}\nk={model.kernel_size}, s=2',
                fontsize=8, ha='center', va='center', color=text_color)
        
        # Arrow down
        if i < len(model.channels) - 1:
            ax.arrow(encoder_x, y_pos - 0.3, 0, -0.2, head_width=0.08, head_length=0.08,
                    fc=encoder_color, ec=encoder_color, linewidth=1.5)
            y_pos -= 0.5
        
        # Calculate next length
        padding = model.kernel_size // 2
        current_len = (current_len + 2 * padding - model.kernel_size) // 2 + 1
        in_channels = out_channels
    
    # Flatten and Linear layers
    y_pos -= 0.3
    ax.arrow(encoder_x, y_pos, 0, -0.2, head_width=0.08, head_length=0.08,
            fc=encoder_color, ec=encoder_color, linewidth=1.5)
    y_pos -= 0.4
    
    flat_box = Rectangle((encoder_x - 0.35, y_pos - 0.25), 0.7, 0.5,
                        facecolor='white', edgecolor=encoder_color, linewidth=1.5)
    ax.add_patch(flat_box)
    ax.text(encoder_x, y_pos, f'Flatten\n[{model.flat_size}]', fontsize=8,
            ha='center', va='center', color=text_color)
    
    y_pos -= 0.4
    ax.arrow(encoder_x, y_pos + 0.25, 0, -0.2, head_width=0.08, head_length=0.08,
            fc=encoder_color, ec=encoder_color, linewidth=1.5)
    y_pos -= 0.3
    
    # Mu and logvar branches
    mu_box = Rectangle((encoder_x - 0.5, y_pos - 0.25), 0.45, 0.5,
                      facecolor='white', edgecolor=encoder_color, linewidth=1.5)
    ax.add_patch(mu_box)
    ax.text(encoder_x - 0.275, y_pos, f'Linear\nμ\n[{model.latent_dim}]',
            fontsize=8, ha='center', va='center', color=text_color)
    
    logvar_box = Rectangle((encoder_x + 0.05, y_pos - 0.25), 0.45, 0.5,
                          facecolor='white', edgecolor=encoder_color, linewidth=1.5)
    ax.add_patch(logvar_box)
    ax.text(encoder_x + 0.275, y_pos, f'Linear\nlog σ²\n[{model.latent_dim}]',
            fontsize=8, ha='center', va='center', color=text_color)
    
    # =====================================================================
    # LATENT SECTION
    # =====================================================================
    latent_box = FancyBboxPatch((latent_x - 0.5, center_y - 1.0), 1.0, 2.0,
                               boxstyle="round,pad=0.1",
                               facecolor=latent_color, alpha=0.2,
                               edgecolor=latent_color, linewidth=2)
    ax.add_patch(latent_box)
    ax.text(latent_x, center_y + 0.9, 'LATENT', fontsize=14, fontweight='bold',
            ha='center', color=latent_color)
    
    # Reparameterization
    z_box = Rectangle((latent_x - 0.4, center_y - 0.3), 0.8, 0.6,
                     facecolor='white', edgecolor=latent_color, linewidth=2)
    ax.add_patch(z_box)
    ax.text(latent_x, center_y, f'z = μ + σ·ε\n[{model.latent_dim}]',
            fontsize=10, ha='center', va='center', color=text_color, fontweight='bold')
    
    # Arrows from encoder to latent
    arrow1 = FancyArrowPatch((encoder_x + 0.4, center_y - 0.5), (latent_x - 0.5, center_y - 0.3),
                            arrowstyle='->', mutation_scale=20, linewidth=2,
                            color=latent_color, zorder=1)
    ax.add_patch(arrow1)
    ax.text((encoder_x + latent_x) / 2, center_y - 0.7, 'μ', fontsize=10,
            ha='center', color=latent_color, fontweight='bold')
    
    arrow2 = FancyArrowPatch((encoder_x + 0.4, center_y + 0.5), (latent_x - 0.5, center_y + 0.3),
                            arrowstyle='->', mutation_scale=20, linewidth=2,
                            color=latent_color, zorder=1)
    ax.add_patch(arrow2)
    ax.text((encoder_x + latent_x) / 2, center_y + 0.7, 'log σ²', fontsize=10,
            ha='center', color=latent_color, fontweight='bold')
    
    # =====================================================================
    # DECODER SECTION
    # =====================================================================
    decoder_box = FancyBboxPatch((decoder_x - 0.4, center_y - 3.5), 0.8, 7.0,
                                boxstyle="round,pad=0.1",
                                facecolor=decoder_color, alpha=0.2,
                                edgecolor=decoder_color, linewidth=2)
    ax.add_patch(decoder_box)
    ax.text(decoder_x, center_y + 3.2, 'DECODER', fontsize=14, fontweight='bold',
            ha='center', color=decoder_color)
    
    # Arrow from latent to decoder
    arrow3 = FancyArrowPatch((latent_x + 0.5, center_y), (decoder_x - 0.4, center_y),
                            arrowstyle='->', mutation_scale=20, linewidth=2,
                            color=decoder_color, zorder=1)
    ax.add_patch(arrow3)
    
    # Linear layer
    y_pos = center_y + 0.3
    linear_box = Rectangle((decoder_x - 0.35, y_pos - 0.3), 0.7, 0.6,
                          facecolor='white', edgecolor=decoder_color, linewidth=1.5)
    ax.add_patch(linear_box)
    ax.text(decoder_x, y_pos, f'Linear\n[{model.latent_dim}]→[{model.flat_size}]',
            fontsize=8, ha='center', va='center', color=text_color)
    
    y_pos -= 0.5
    ax.arrow(decoder_x, y_pos + 0.3, 0, -0.2, head_width=0.08, head_length=0.08,
            fc=decoder_color, ec=decoder_color, linewidth=1.5)
    y_pos -= 0.3
    
    # Reshape
    reshape_box = Rectangle((decoder_x - 0.35, y_pos - 0.25), 0.7, 0.5,
                           facecolor='white', edgecolor=decoder_color, linewidth=1.5)
    ax.add_patch(reshape_box)
    ax.text(decoder_x, y_pos, f'Reshape\n[{model.channels[-1]}, {model.encoded_len}]',
            fontsize=8, ha='center', va='center', color=text_color)
    
    # Decoder ConvTranspose layers
    reversed_channels = list(reversed(model.channels))
    in_channels = model.channels[-1]
    
    for i, out_channels in enumerate(reversed_channels[1:] + [1]):
        y_pos -= 0.4
        ax.arrow(decoder_x, y_pos + 0.25, 0, -0.2, head_width=0.08, head_length=0.08,
                fc=decoder_color, ec=decoder_color, linewidth=1.5)
        y_pos -= 0.3
        
        convt_box = Rectangle((decoder_x - 0.35, y_pos - 0.3), 0.7, 0.6,
                             facecolor='white', edgecolor=decoder_color, linewidth=1.5)
        ax.add_patch(convt_box)
        if out_channels == 1:
            ax.text(decoder_x, y_pos, f'ConvTranspose1d\n{in_channels}→{out_channels}',
                    fontsize=8, ha='center', va='center', color=text_color)
        else:
            ax.text(decoder_x, y_pos, f'ConvTranspose1d\n{in_channels}→{out_channels}\ns=2',
                    fontsize=8, ha='center', va='center', color=text_color)
        
        in_channels = out_channels
    
    # Output
    y_pos -= 0.4
    ax.arrow(decoder_x, y_pos + 0.25, 0, -0.2, head_width=0.08, head_length=0.08,
            fc=decoder_color, ec=decoder_color, linewidth=1.5)
    y_pos -= 0.3
    
    output_box = Rectangle((decoder_x - 0.3, y_pos - 0.2), 0.6, 0.4,
                          facecolor='white', edgecolor=decoder_color, linewidth=1.5)
    ax.add_patch(output_box)
    ax.text(decoder_x, y_pos, f'Output\n[{seq_len}]', fontsize=9,
            ha='center', va='center', color=text_color)
    
    # Model info at bottom
    info_text = (f"Parameters: {count_parameters(model):,} | "
                f"Kernel Size: {model.kernel_size} | "
                f"Latent Dim: {model.latent_dim}")
    ax.text(5, 0.5, info_text, fontsize=10, ha='center', color=text_color,
            style='italic')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Model architecture plot saved to: {save_path}")

