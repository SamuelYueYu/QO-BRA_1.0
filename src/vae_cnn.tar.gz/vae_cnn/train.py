#!/usr/bin/env python
"""
VAE CNN - Training Script

Train a 1D-CNN based Variational Autoencoder for protein sequence generation.

Usage:
    python train.py --metal Ca --epochs 500 --deterministic
    python train.py --metal Mg --beta 0.01 --beta_warmup 100
"""

import os
import argparse
import numpy as np
import torch
import torch.optim as optim
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from model import ConvVAE, vae_loss
from data import load_data, get_dataloaders, tokens_to_sequence
from utils import (set_seed, save_checkpoint, load_checkpoint, 
                   EarlyStopping, save_model_summary, plot_model_architecture)
from metrics import (compute_all_metrics, compute_nuv, compute_reconstruction_rate,
                     compute_all_relative_ratios)


def plot_losses(history, save_path):
    """Plot training history and save to file."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    epochs = range(1, len(history['train_loss']) + 1)
    
    # Total loss
    ax = axes[0, 0]
    ax.plot(epochs, history['train_loss'], 'b-', label='Train', alpha=0.7)
    ax.plot(epochs, history['val_loss'], 'r-', label='Val', alpha=0.7)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Total Loss')
    ax.set_title('Total Loss (Recon + β·KL)')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Reconstruction loss
    ax = axes[0, 1]
    ax.plot(epochs, history['train_recon'], 'b-', label='Train', alpha=0.7)
    ax.plot(epochs, history['val_recon'], 'r-', label='Val', alpha=0.7)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Reconstruction Loss')
    ax.set_title('Reconstruction Loss (MSE)')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # KL divergence
    ax = axes[1, 0]
    ax.plot(epochs, history['train_kl'], 'b-', label='Train', alpha=0.7)
    ax.plot(epochs, history['val_kl'], 'r-', label='Val', alpha=0.7)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('KL Divergence')
    ax.set_title('KL Divergence')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Beta schedule
    ax = axes[1, 1]
    ax.plot(epochs, history['beta'], 'g-', linewidth=2)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Beta')
    ax.set_title('Beta Schedule')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='Train a 1D-CNN VAE for sequence generation',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    # Data arguments
    parser.add_argument('--metal', type=str, required=True, choices=['Ca', 'Mg', 'Zn'],
                        help='Metal type subfolder to use (Ca, Mg, or Zn)')
    parser.add_argument('--data_dir', type=str, default='../src/Training data',
                        help='Path to Training data directory')
    parser.add_argument('--max_len', type=int, default=128,
                        help='Maximum sequence length')
    parser.add_argument('--val_split', type=float, default=0.2,
                        help='Fraction of data for validation')
    
    # Model arguments
    parser.add_argument('--latent_dim', type=int, default=32,
                        help='Latent space dimension')
    parser.add_argument('--channels', type=str, default='32,64,128',
                        help='Comma-separated channel sizes for conv layers')
    parser.add_argument('--kernel_size', type=int, default=5,
                        help='Kernel size for conv layers')
    parser.add_argument('--dropout', type=float, default=0.1,
                        help='Dropout rate (0 to disable)')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, default=500,
                        help='Maximum number of training epochs')
    parser.add_argument('--batch_size', type=int, default=256,
                        help='Batch size')
    parser.add_argument('--lr', type=float, default=1e-3,
                        help='Learning rate')
    parser.add_argument('--beta', type=float, default=1.0,
                        help='Final beta weight for KL term (beta-VAE)')
    parser.add_argument('--beta_warmup', type=int, default=50,
                        help='Epochs to linearly anneal beta from 0 to target')
    parser.add_argument('--patience', type=int, default=50,
                        help='Early stopping patience')
    parser.add_argument('--deterministic', action='store_true',
                        help='Use deterministic mode (mu only, no sampling) for reconstruction')
    
    # Output arguments
    parser.add_argument('--output_dir', type=str, default=None,
                        help='Output directory (default: ./outputs/{metal})')
    parser.add_argument('--seed', type=int, default=42,
                        help='Random seed')
    parser.add_argument('--log_every', type=int, default=10,
                        help='Log training progress every N epochs')
    parser.add_argument('--n_samples', type=int, default=100,
                        help='Number of samples to generate for evaluation')
    
    return parser.parse_args()


def train_epoch(model, train_loader, optimizer, device, beta, deterministic=False):
    """Train for one epoch."""
    model.train()
    total_loss = 0.0
    total_recon = 0.0
    total_kl = 0.0
    n_batches = 0
    
    for batch in train_loader:
        x = batch.to(device)
        optimizer.zero_grad()
        
        x_recon, mu, logvar = model(x, deterministic=deterministic)
        loss, recon, kl = vae_loss(x, x_recon, mu, logvar, beta)
        
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        total_recon += recon.item()
        total_kl += kl.item()
        n_batches += 1
    
    return {
        'loss': total_loss / n_batches,
        'recon': total_recon / n_batches,
        'kl': total_kl / n_batches,
    }


def validate(model, val_loader, device, beta, deterministic=False):
    """Validate the model."""
    model.eval()
    total_loss = 0.0
    total_recon = 0.0
    total_kl = 0.0
    n_batches = 0
    
    with torch.no_grad():
        for batch in val_loader:
            x = batch.to(device)
            x_recon, mu, logvar = model(x, deterministic=deterministic)
            loss, recon, kl = vae_loss(x, x_recon, mu, logvar, beta)
            
            total_loss += loss.item()
            total_recon += recon.item()
            total_kl += kl.item()
            n_batches += 1
    
    return {
        'loss': total_loss / n_batches,
        'recon': total_recon / n_batches,
        'kl': total_kl / n_batches,
    }


def main():
    args = parse_args()
    
    # Parse channels
    channels = [int(c) for c in args.channels.split(',')]
    
    # Set up output directory
    if args.output_dir is None:
        args.output_dir = f'./outputs/{args.metal}'
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Set seeds for reproducibility
    set_seed(args.seed)
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load data
    print(f"\nLoading data from {os.path.abspath(args.data_dir)}/{args.metal}_bind/")
    train_dataset, val_dataset, token_to_value, value_to_token = load_data(
        args.data_dir, args.metal, args.max_len, args.val_split, args.seed
    )
    
    train_loader, val_loader = get_dataloaders(
        train_dataset, val_dataset, args.batch_size
    )
    
    print(f"Train batches: {len(train_loader)}, Val batches: {len(val_loader)}")
    
    # Create model
    model = ConvVAE(
        seq_len=args.max_len,
        latent_dim=args.latent_dim,
        channels=channels,
        kernel_size=args.kernel_size,
        dropout=args.dropout,
    ).to(device)
    
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\nModel parameters: {n_params:,}")
    print(f"Channels: {channels}")
    print(f"Latent dim: {args.latent_dim}")
    print(f"Deterministic mode: {args.deterministic}")
    
    # Save architecture summary
    save_model_summary(model, os.path.join(args.output_dir, 'architecture_summary.txt'), args.max_len)
    
    # Plot architecture diagram
    plot_model_architecture(model, args.max_len, 
                            os.path.join(args.output_dir, 'architecture_diagram.png'))
    
    # Optimizer
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    
    # Early stopping
    early_stopping = EarlyStopping(patience=args.patience)
    
    # Training log
    log_path = os.path.join(args.output_dir, 'training_log.txt')
    with open(log_path, 'w') as f:
        f.write('epoch\ttrain_loss\ttrain_recon\ttrain_kl\tval_loss\tval_recon\tval_kl\tbeta\n')
    
    # Loss history for plotting
    history = {
        'train_loss': [], 'val_loss': [],
        'train_recon': [], 'val_recon': [],
        'train_kl': [], 'val_kl': [],
        'beta': []
    }
    plot_path = os.path.join(args.output_dir, 'training_losses.png')
    
    # Training loop
    best_val_loss = float('inf')
    print(f"\nTraining for up to {args.epochs} epochs...")
    print("-" * 80)
    
    for epoch in range(1, args.epochs + 1):
        # Beta annealing: linearly increase beta from 0 to target over warmup epochs
        if args.beta_warmup > 0 and epoch <= args.beta_warmup:
            current_beta = args.beta * (epoch / args.beta_warmup)
        else:
            current_beta = args.beta
        
        train_metrics = train_epoch(model, train_loader, optimizer, device, current_beta,
                                     deterministic=args.deterministic)
        val_metrics = validate(model, val_loader, device, current_beta,
                               deterministic=args.deterministic)
        
        # Update history
        history['train_loss'].append(train_metrics['loss'])
        history['val_loss'].append(val_metrics['loss'])
        history['train_recon'].append(train_metrics['recon'])
        history['val_recon'].append(val_metrics['recon'])
        history['train_kl'].append(train_metrics['kl'])
        history['val_kl'].append(val_metrics['kl'])
        history['beta'].append(current_beta)
        
        # Log to file
        with open(log_path, 'a') as f:
            f.write(f"{epoch}\t{train_metrics['loss']:.6f}\t{train_metrics['recon']:.6f}\t"
                    f"{train_metrics['kl']:.6f}\t{val_metrics['loss']:.6f}\t"
                    f"{val_metrics['recon']:.6f}\t{val_metrics['kl']:.6f}\t{current_beta:.6f}\n")
        
        # Update loss plot
        if epoch % args.log_every == 0 or epoch == 1:
            plot_losses(history, plot_path)
        
        # Print progress
        if epoch % args.log_every == 0 or epoch == 1:
            print(f"Epoch {epoch:4d} | β={current_beta:.3f} | "
                  f"Train: {train_metrics['loss']:.4f} (R:{train_metrics['recon']:.4f} KL:{train_metrics['kl']:.4f}) | "
                  f"Val: {val_metrics['loss']:.4f}")
        
        # Save best model
        if val_metrics['loss'] < best_val_loss:
            best_val_loss = val_metrics['loss']
            save_checkpoint(model, optimizer, epoch, val_metrics['loss'],
                          os.path.join(args.output_dir, 'best_model.pt'))
        
        # Early stopping check
        if early_stopping(val_metrics['loss']):
            print(f"\nEarly stopping triggered at epoch {epoch}")
            break
    
    print("-" * 80)
    print(f"Training complete. Best val loss: {best_val_loss:.4f}")
    
    # Final plot
    plot_losses(history, plot_path)
    
    # Save final model
    save_checkpoint(model, optimizer, epoch, val_metrics['loss'],
                   os.path.join(args.output_dir, 'final_model.pt'))
    
    # Load best model for evaluation
    load_checkpoint(model, optimizer, 
                   os.path.join(args.output_dir, 'best_model.pt'), device)
    
    # ========================================================================
    # EVALUATION
    # ========================================================================
    print("\n" + "=" * 80)
    print("EVALUATION")
    print("=" * 80)
    
    # Compute metrics on validation set
    metrics = compute_all_metrics(model, val_loader, device, args.beta, token_to_value)
    print(f"\nValidation Metrics:")
    print(f"  MSE:  {metrics['mse']:.6f}")
    print(f"  KL:   {metrics['kl']:.6f}")
    print(f"  ELBO: {metrics['elbo']:.6f}")
    if 'token_accuracy' in metrics:
        print(f"  Token accuracy: {metrics['token_accuracy']:.6f}")
        print(f"  Exact match rate: {metrics['exact_match_rate']:.6f}")
    
    # Get training sequences for comparison
    training_seqs = train_dataset.sequences
    
    # Get reconstructed sequences for R metric
    print(f"\nComputing reconstructions for R metric...")
    model.eval()
    original_seqs = []
    reconstructed_seqs = []
    with torch.no_grad():
        for batch in val_loader:
            x = batch.to(device)
            x_recon, mu, logvar = model(x, deterministic=True)
            x_recon = torch.clamp(x_recon, 0.0, 1.0)
            
            # Convert to sequences
            for i in range(x.size(0)):
                orig_seq = tokens_to_sequence(x[i].cpu().numpy(), value_to_token, token_to_value)
                recon_seq = tokens_to_sequence(x_recon[i].cpu().numpy(), value_to_token, token_to_value)
                original_seqs.append(orig_seq)
                reconstructed_seqs.append(recon_seq)
    
    # Generate samples
    print(f"\nGenerating {args.n_samples} samples...")
    model.eval()
    with torch.no_grad():
        samples = model.sample(args.n_samples, device)
        # Clamp samples to valid range
        samples = torch.clamp(samples, 0.0, 1.0)
    
    # Convert samples to sequences
    sample_seqs = []
    for i in range(args.n_samples):
        seq = tokens_to_sequence(samples[i].cpu().numpy(), value_to_token, token_to_value)
        sample_seqs.append(seq)
    
    # ========================================================================
    # COMPUTE N, U, V, R, RR METRICS
    # ========================================================================
    print("\nComputing generation quality metrics (N, U, V, R, RR)...")
    
    # Reconstruction rate (exact sequence matches)
    R = compute_reconstruction_rate(original_seqs, reconstructed_seqs)
    print(f"  R (exact reconstruction rate): {R:.6f}")
    
    # NUV metrics on generated samples
    nuv = compute_nuv(sample_seqs, training_seqs)
    print(f"  N (novelty): {nuv['N']:.6f}")
    print(f"  U (uniqueness): {nuv['U']:.6f}")
    print(f"  V (validity): {nuv['V']:.6f}")
    
    # Relative ratio metrics
    rr = compute_all_relative_ratios(training_seqs, sample_seqs, max_len=args.max_len)
    print(f"  RR_aa: mean={rr['RR_aa']['mean']:.6f}, std={rr['RR_aa']['std']:.6f}")
    print(f"  RR_length: mean={rr['RR_length']['mean']:.6f}, std={rr['RR_length']['std']:.6f}")
    print(f"  RR_binding: mean={rr['RR_binding_sites']['mean']:.6f}, std={rr['RR_binding_sites']['std']:.6f}")
    print(f"  RR_chains: mean={rr['RR_chains']['mean']:.6f}, std={rr['RR_chains']['std']:.6f}")
    
    # Save generated sequences
    gen_path = os.path.join(args.output_dir, 'generated_sequences.txt')
    with open(gen_path, 'w') as f:
        for i, seq in enumerate(sample_seqs):
            f.write(f">{i+1}\n{seq}\n")
    print(f"Generated sequences saved to: {gen_path}")
    
    # Save metrics
    metrics_path = os.path.join(args.output_dir, 'metrics.txt')
    with open(metrics_path, 'w') as f:
        f.write("CNN VAE Evaluation Metrics\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Metal type: {args.metal}\n")
        f.write(f"Latent dim: {args.latent_dim}\n")
        f.write(f"Channels: {channels}\n")
        f.write(f"Beta: {args.beta}\n")
        f.write(f"Deterministic: {args.deterministic}\n")
        f.write(f"Training samples: {len(train_dataset)}\n")
        f.write(f"Generated samples: {args.n_samples}\n\n")
        f.write("--- VAE Metrics ---\n")
        f.write(f"  MSE:  {metrics['mse']:.6f}\n")
        f.write(f"  KL:   {metrics['kl']:.6f}\n")
        f.write(f"  ELBO: {metrics['elbo']:.6f}\n\n")
        if 'token_accuracy' in metrics:
            f.write("--- Reconstruction Metrics ---\n")
            f.write(f"  Token accuracy: {metrics['token_accuracy']:.6f}\n")
            f.write(f"  R (exact match rate): {R:.6f}\n\n")
        f.write("--- Generation Quality (NUV) ---\n")
        f.write(f"  N (novelty): {nuv['N']:.6f}\n")
        f.write(f"  U (uniqueness): {nuv['U']:.6f}\n")
        f.write(f"  V (validity): {nuv['V']:.6f}\n\n")
        f.write("--- Relative Ratios (RR) ---\n")
        f.write(f"  RR_aa: mean={rr['RR_aa']['mean']:.6f}, std={rr['RR_aa']['std']:.6f}\n")
        f.write(f"  RR_length: mean={rr['RR_length']['mean']:.6f}, std={rr['RR_length']['std']:.6f}\n")
        f.write(f"  RR_binding_sites: mean={rr['RR_binding_sites']['mean']:.6f}, std={rr['RR_binding_sites']['std']:.6f}\n")
        f.write(f"  RR_chains: mean={rr['RR_chains']['mean']:.6f}, std={rr['RR_chains']['std']:.6f}\n")
    
    print(f"Metrics saved to: {metrics_path}")
    print("\nDone!")


if __name__ == '__main__':
    main()

