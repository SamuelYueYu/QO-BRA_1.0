"""
VAE CNN - Metrics Module

This module provides metrics for evaluating the VAE model, including:
- Reconstruction MSE, KL divergence, ELBO
- Token accuracy
- N (Novelty): fraction of generated sequences not similar to training
- U (Uniqueness): fraction of unique generated sequences
- V (Validity): fraction passing biological validity checks
- R (Reconstruction rate): fraction of perfectly reconstructed sequences
- RR (Relative Ratio): distribution similarity between generated and training
"""

import re
import difflib
import numpy as np
import torch
import torch.nn.functional as F
from collections import Counter


def reconstruction_mse(x: torch.Tensor, x_recon: torch.Tensor) -> float:
    """
    Compute mean squared error between original and reconstructed sequences.
    
    Parameters:
    - x: Original sequences (batch, seq_len)
    - x_recon: Reconstructed sequences (batch, seq_len)
    
    Returns:
    - mse: Mean squared error (scalar)
    """
    return F.mse_loss(x_recon, x, reduction='mean').item()


def kl_divergence(mu: torch.Tensor, logvar: torch.Tensor) -> float:
    """
    Compute KL divergence between posterior and prior.
    
    KL(q(z|x) || p(z)) = -0.5 * sum(1 + logvar - mu^2 - exp(logvar))
    
    Parameters:
    - mu: Latent mean (batch, latent_dim)
    - logvar: Latent log variance (batch, latent_dim)
    
    Returns:
    - kl: KL divergence (scalar)
    """
    kl = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return (kl / mu.size(0)).item()


def elbo(x: torch.Tensor, x_recon: torch.Tensor,
         mu: torch.Tensor, logvar: torch.Tensor,
         beta: float = 1.0) -> float:
    """
    Compute the Evidence Lower Bound.
    
    ELBO = E[log p(x|z)] - beta * KL(q(z|x) || p(z))
    
    We return the negative ELBO (loss), so lower is better.
    """
    recon = F.mse_loss(x_recon, x, reduction='sum') / x.size(0)
    kl = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / x.size(0)
    return (recon + beta * kl).item()


def token_accuracy(x: torch.Tensor, x_recon: torch.Tensor, 
                   token_values: np.ndarray, threshold: float = None) -> float:
    """
    Compute token-level accuracy by rounding to nearest token.
    
    Parameters:
    - x: Original sequences (batch, seq_len)
    - x_recon: Reconstructed sequences (batch, seq_len)
    - token_values: Array of valid token values
    - threshold: If provided, use threshold-based matching instead of nearest
    
    Returns:
    - accuracy: Fraction of correctly reconstructed tokens
    """
    x_np = x.cpu().numpy()
    x_recon_np = x_recon.cpu().numpy()
    
    # Find nearest token for each position
    def to_token_idx(values):
        # Expand dimensions for broadcasting
        values = values[..., np.newaxis]  # (batch, seq, 1)
        token_vals = token_values[np.newaxis, np.newaxis, :]  # (1, 1, vocab)
        dists = np.abs(values - token_vals)
        return np.argmin(dists, axis=-1)
    
    orig_tokens = to_token_idx(x_np)
    recon_tokens = to_token_idx(x_recon_np)
    
    # Only count non-padding positions (where original > 0)
    mask = x_np >= 0
    correct = (orig_tokens == recon_tokens) & mask
    
    return correct.sum() / mask.sum()


def exact_match_rate(x: torch.Tensor, x_recon: torch.Tensor,
                     token_values: np.ndarray) -> float:
    """
    Compute fraction of sequences that are perfectly reconstructed.
    
    Parameters:
    - x: Original sequences (batch, seq_len)
    - x_recon: Reconstructed sequences (batch, seq_len)
    - token_values: Array of valid token values
    
    Returns:
    - rate: Fraction of exact matches
    """
    x_np = x.cpu().numpy()
    x_recon_np = x_recon.cpu().numpy()
    
    def to_token_idx(values):
        values = values[..., np.newaxis]
        token_vals = token_values[np.newaxis, np.newaxis, :]
        dists = np.abs(values - token_vals)
        return np.argmin(dists, axis=-1)
    
    orig_tokens = to_token_idx(x_np)
    recon_tokens = to_token_idx(x_recon_np)
    
    # Check if all tokens match for each sequence
    mask = x_np >= 0
    matches = []
    for i in range(len(x_np)):
        seq_mask = mask[i]
        seq_match = np.all(orig_tokens[i][seq_mask] == recon_tokens[i][seq_mask])
        matches.append(seq_match)
    
    return np.mean(matches)


# =============================================================================
# SEQUENCE SIMILARITY (for Novelty computation)
# =============================================================================


def longest_common_substring(str1: str, str2: str) -> int:
    """Calculate the Longest Common Substring (LCS) length between two strings."""
    if not str1 or not str2:
        return 0
    s = difflib.SequenceMatcher(None, str1, str2)
    match = s.find_longest_match(0, len(str1), 0, len(str2))
    return match.size


def is_similar(str1: str, str2: str, threshold: float = 0.1) -> bool:
    """Determine if two sequences are significantly similar."""
    if not str1 or not str2:
        return False
    lcs_len = longest_common_substring(str1, str2)
    return (lcs_len / len(str1) > threshold) and (lcs_len / len(str2) > threshold)


# =============================================================================
# N, U, V METRICS
# =============================================================================

PATTERN_3_CONSECUTIVE = r".\+.\+.\+"        # 3 consecutive binding sites
PATTERN_5_CONSECUTIVE = r".\+.\+.\+.\+.\+"  # 5 consecutive binding sites
MIN_CHAIN_LENGTH = 4  # Minimum chain length threshold


def compute_novelty(generated_seqs: list, training_seqs: list,
                    similarity_threshold: float = 0.1) -> float:
    """
    Compute novelty rate (N): fraction of generated sequences not similar to training.
    
    A sequence is novel if it is NOT similar to ANY training sequence.
    Similarity is determined by LCS: similar if >10% of both sequences match.
    """
    if not generated_seqs:
        return 0.0
    
    novel_count = 0
    for gen_seq in generated_seqs:
        idx = gen_seq.find('X')
        gen_clean = gen_seq[:idx] if idx != -1 else gen_seq
        
        is_novel = True
        for train_seq in training_seqs:
            idx = train_seq.find('X')
            train_clean = train_seq[:idx] if idx != -1 else train_seq
            
            if is_similar(gen_clean, train_clean, similarity_threshold):
                is_novel = False
                break
        
        if is_novel:
            novel_count += 1
    
    return novel_count / len(generated_seqs)


def compute_uniqueness(generated_seqs: list) -> float:
    """Compute uniqueness rate (U): fraction of unique sequences among generated."""
    if not generated_seqs:
        return 0.0
    
    cleaned = []
    for seq in generated_seqs:
        idx = seq.find('X')
        cleaned.append(seq[:idx] if idx != -1 else seq)
    
    unique_seqs = set(cleaned)
    return len(unique_seqs) / len(generated_seqs)


def compute_validity(generated_seqs: list, min_chain_length: int = MIN_CHAIN_LENGTH) -> float:
    """
    Compute validity rate (V): fraction passing biological validity checks.
    
    Validity criteria:
    1. Must have binding sites ('+' present)
    2. No consecutive chain separators ('::')
    3. No 5+ consecutive binding sites
    4. Less than 2 occurrences of 3 consecutive binding sites
    5. All chains meet minimum length requirement
    """
    if not generated_seqs:
        return 0.0
    
    valid_count = 0
    for seq in generated_seqs:
        idx = seq.find('X')
        s = seq[:idx] if idx != -1 else seq
        
        # Check 1: Must have binding sites
        if '+' not in s:
            continue
        
        # Check 2: No consecutive chain separators
        if '::' in s:
            continue
        
        # Check 3: No 5+ consecutive binding sites
        match5 = re.findall(PATTERN_5_CONSECUTIVE, s)
        if len(match5) > 0:
            continue
        
        # Check 4: Less than 2 occurrences of 3 consecutive binding sites
        match3 = re.findall(PATTERN_3_CONSECUTIVE, s)
        if len(match3) >= 2:
            continue
        
        # Check 5: All chains meet minimum length
        s_no_plus = ''.join([c for c in s if c != '+'])
        chains = s_no_plus.split(':')
        chains = [c for c in chains if c]
        
        if ':' not in s_no_plus:
            if len(s_no_plus) >= min_chain_length:
                valid_count += 1
        else:
            if all(len(c) >= min_chain_length for c in chains):
                valid_count += 1
    
    return valid_count / len(generated_seqs)


def compute_nuv(generated_seqs: list, training_seqs: list,
                min_chain_length: int = MIN_CHAIN_LENGTH,
                similarity_threshold: float = 0.1) -> dict:
    """Compute all NUV metrics: Novelty, Uniqueness, Validity rates."""
    return {
        'N': compute_novelty(generated_seqs, training_seqs, similarity_threshold),
        'U': compute_uniqueness(generated_seqs),
        'V': compute_validity(generated_seqs, min_chain_length),
    }


# =============================================================================
# R (RECONSTRUCTION RATE) METRIC
# =============================================================================

def compute_reconstruction_rate(original_seqs: list, reconstructed_seqs: list,
                                 tolerance: float = 0.0) -> float:
    """
    Compute reconstruction rate (R): fraction of perfectly reconstructed sequences.
    
    A sequence is "perfectly reconstructed" if it exactly matches the original.
    """
    if not original_seqs or len(original_seqs) != len(reconstructed_seqs):
        return 0.0
    
    perfect_count = 0
    for orig, recon in zip(original_seqs, reconstructed_seqs):
        if tolerance == 0.0:
            if orig == recon:
                perfect_count += 1
        else:
            min_len = min(len(orig), len(recon))
            if min_len == 0:
                continue
            mismatches = sum(1 for i in range(min_len) if orig[i] != recon[i])
            mismatches += abs(len(orig) - len(recon))
            if mismatches / len(orig) <= tolerance:
                perfect_count += 1
    
    return perfect_count / len(original_seqs)


# =============================================================================
# RR (RELATIVE RATIO) METRICS
# =============================================================================

def extract_tokens(sequence: str) -> list:
    """Extract tokens from a sequence string."""
    tokens = []
    i = 0
    idx = sequence.find('X')
    seq = sequence[:idx] if idx != -1 else sequence
    
    while i < len(seq):
        if i < len(seq) - 1 and seq[i + 1] in ['+', 'X']:
            tokens.append(seq[i:i + 2])
            i += 2
        else:
            tokens.append(seq[i])
            i += 1
    return tokens


def compute_aa_frequencies(sequences: list) -> dict:
    """Compute amino acid/token frequency distribution."""
    all_tokens = []
    for seq in sequences:
        all_tokens.extend(extract_tokens(seq))
    
    counts = Counter(all_tokens)
    total = sum(counts.values())
    if total == 0:
        return {}
    return {k: v / total for k, v in counts.items()}


def compute_sequence_lengths(sequences: list) -> list:
    """Compute sequence lengths (excluding special characters)."""
    lengths = []
    for seq in sequences:
        idx = seq.find('X')
        s = seq[:idx] if idx != -1 else seq
        length = len(''.join([c for c in s if c not in ['+', ':']]))
        lengths.append(length)
    return lengths


def compute_binding_site_counts(sequences: list) -> list:
    """Count binding sites per sequence."""
    counts = []
    for seq in sequences:
        idx = seq.find('X')
        s = seq[:idx] if idx != -1 else seq
        counts.append(s.count('+'))
    return counts


def compute_chain_counts(sequences: list) -> list:
    """Count chains per sequence."""
    counts = []
    for seq in sequences:
        idx = seq.find('X')
        s = seq[:idx] if idx != -1 else seq
        counts.append(s.count(':'))
    return counts


def compute_relative_ratio_discrete(train_values: list, gen_values: list) -> dict:
    """Compute relative ratio for discrete property values."""
    train_counts = Counter(train_values)
    gen_counts = Counter(gen_values)
    
    train_total = sum(train_counts.values())
    gen_total = sum(gen_counts.values())
    
    if train_total == 0 or gen_total == 0:
        return {'mean': 0.0, 'std': 0.0}
    
    train_freq = {k: v / train_total for k, v in train_counts.items()}
    gen_freq = {k: v / gen_total for k, v in gen_counts.items()}
    
    relative_ratios = []
    for k in train_freq:
        if train_freq[k] > 0:
            gen_f = gen_freq.get(k, 0)
            relative_ratios.append(gen_f / train_freq[k])
    
    if not relative_ratios:
        return {'mean': 0.0, 'std': 0.0}
    
    return {
        'mean': float(np.mean(relative_ratios)),
        'std': float(np.std(relative_ratios)),
    }


def compute_relative_ratio_length(train_lengths: list, gen_lengths: list,
                                   bin_size: int = 8, max_len: int = 256) -> dict:
    """Compute relative ratio for sequence lengths using binning."""
    bins = list(range(0, max_len + bin_size, bin_size))
    train_binned = [0] * (len(bins) - 1)
    gen_binned = [0] * (len(bins) - 1)
    
    for length in train_lengths:
        for i in range(len(bins) - 1):
            if bins[i] <= length < bins[i + 1]:
                train_binned[i] += 1
                break
    
    for length in gen_lengths:
        for i in range(len(bins) - 1):
            if bins[i] <= length < bins[i + 1]:
                gen_binned[i] += 1
                break
    
    train_total = sum(train_binned)
    gen_total = sum(gen_binned)
    
    if train_total == 0 or gen_total == 0:
        return {'mean': 0.0, 'std': 0.0}
    
    train_freq = [c / train_total for c in train_binned]
    gen_freq = [c / gen_total for c in gen_binned]
    
    relative_ratios = []
    for i in range(len(train_freq)):
        if train_freq[i] > 0:
            relative_ratios.append(gen_freq[i] / train_freq[i])
    
    if not relative_ratios:
        return {'mean': 0.0, 'std': 0.0}
    
    return {
        'mean': float(np.mean(relative_ratios)),
        'std': float(np.std(relative_ratios)),
    }


def compute_relative_ratio_aa(train_seqs: list, gen_seqs: list) -> dict:
    """Compute relative ratio for amino acid frequencies."""
    train_freq = compute_aa_frequencies(train_seqs)
    gen_freq = compute_aa_frequencies(gen_seqs)
    
    if not train_freq or not gen_freq:
        return {'mean': 0.0, 'std': 0.0}
    
    relative_ratios = []
    for token in train_freq:
        if train_freq[token] > 0:
            gen_f = gen_freq.get(token, 0)
            relative_ratios.append(gen_f / train_freq[token])
    
    if not relative_ratios:
        return {'mean': 0.0, 'std': 0.0}
    
    return {
        'mean': float(np.mean(relative_ratios)),
        'std': float(np.std(relative_ratios)),
    }


def compute_all_relative_ratios(train_seqs: list, gen_seqs: list,
                                 max_len: int = 256) -> dict:
    """Compute all relative ratio metrics."""
    rr_aa = compute_relative_ratio_aa(train_seqs, gen_seqs)
    
    train_lens = compute_sequence_lengths(train_seqs)
    gen_lens = compute_sequence_lengths(gen_seqs)
    rr_length = compute_relative_ratio_length(train_lens, gen_lens, max_len=max_len)
    
    train_plus = compute_binding_site_counts(train_seqs)
    gen_plus = compute_binding_site_counts(gen_seqs)
    rr_binding = compute_relative_ratio_discrete(train_plus, gen_plus)
    
    train_chains = compute_chain_counts(train_seqs)
    gen_chains = compute_chain_counts(gen_seqs)
    rr_chains = compute_relative_ratio_discrete(train_chains, gen_chains)
    
    return {
        'RR_aa': rr_aa,
        'RR_length': rr_length,
        'RR_binding_sites': rr_binding,
        'RR_chains': rr_chains,
    }


def compute_all_metrics(model, dataloader, device, beta=1.0, token_to_value=None):
    """
    Compute all metrics on a dataset.
    
    Parameters:
    - model: VAE model
    - dataloader: DataLoader
    - device: Device
    - beta: Beta for ELBO computation
    - token_to_value: Token to value mapping (optional, for token accuracy)
    
    Returns:
    - metrics: Dictionary of metric values
    """
    model.eval()
    
    total_mse = 0.0
    total_kl = 0.0
    total_elbo = 0.0
    total_samples = 0
    
    all_x = []
    all_x_recon = []
    
    with torch.no_grad():
        for batch in dataloader:
            x = batch.to(device)
            # Clamp reconstructed values to [0, 1] range to ensure valid token values
            x_recon, mu, logvar = model(x, deterministic=True)  # Use deterministic for evaluation
            x_recon = torch.clamp(x_recon, 0.0, 1.0)  # Ensure outputs are in valid range
            
            batch_size = x.size(0)
            total_mse += reconstruction_mse(x, x_recon) * batch_size
            total_kl += kl_divergence(mu, logvar) * batch_size
            total_elbo += elbo(x, x_recon, mu, logvar, beta) * batch_size
            total_samples += batch_size
            
            all_x.append(x)
            all_x_recon.append(x_recon)
    
    metrics = {
        'mse': total_mse / total_samples,
        'kl': total_kl / total_samples,
        'elbo': total_elbo / total_samples,
    }
    
    # Compute token-level metrics if token mapping provided
    if token_to_value is not None:
        all_x = torch.cat(all_x, dim=0)
        all_x_recon = torch.cat(all_x_recon, dim=0)
        token_values = np.array(list(token_to_value.values()))
        
        metrics['token_accuracy'] = token_accuracy(all_x, all_x_recon, token_values)
        metrics['exact_match_rate'] = exact_match_rate(all_x, all_x_recon, token_values)
    
    return metrics

